#ifndef AS5600_H
#define AS5600_H

#include "stm32f4xx_hal.h"  // change to match your STM32 series

#define AS5600_ADDRESS      (0x36 << 1)
#define AS5600_RAW_ANGLE_H  0x0C
#define AS5600_RAW_ANGLE_L  0x0D

typedef struct {
    I2C_HandleTypeDef *hi2c;
    float angle_deg;         // current angle in degrees
    float velocity_deg_s;    // velocity in degrees/s
    float prev_angle;        // previous angle for velocity calc
} AS5600_HandleTypeDef;

HAL_StatusTypeDef AS5600_Init(AS5600_HandleTypeDef *dev, I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef AS5600_Update(AS5600_HandleTypeDef *dev, float dt);

#endif
