#include "AS5600.h"

HAL_StatusTypeDef AS5600_Init(AS5600_HandleTypeDef *dev, I2C_HandleTypeDef *hi2c)
{
    dev->hi2c           = hi2c;
    dev->angle_deg      = 0.0f;
    dev->velocity_deg_s = 0.0f;
    dev->prev_angle     = 0.0f;

    // Check device is present on bus
    HAL_StatusTypeDef status = HAL_I2C_IsDeviceReady(hi2c, AS5600_ADDRESS, 3, 100);
    return status;
}

HAL_StatusTypeDef AS5600_Update(AS5600_HandleTypeDef *dev, float dt)
{
    uint8_t buf[2];

    HAL_StatusTypeDef status = HAL_I2C_Mem_Read(
        dev->hi2c,
        AS5600_ADDRESS,
        AS5600_RAW_ANGLE_H,
        I2C_MEMADD_SIZE_8BIT,
        buf, 2, 100
    );

    if (status != HAL_OK) return status;

    // Convert raw 12-bit value to degrees
    uint16_t raw = ((buf[0] & 0x0F) << 8) | buf[1];
    float angle  = (raw / 4096.0f) * 360.0f;

    // Calculate velocity with wrap-around handling
    float delta = angle - dev->prev_angle;
    if (delta >  180.0f) delta -= 360.0f;  // handle 359 -> 0 wrap
    if (delta < -180.0f) delta += 360.0f;  // handle 0 -> 359 wrap

    dev->velocity_deg_s = delta / dt;
    dev->angle_deg      = angle;
    dev->prev_angle     = angle;

    return HAL_OK;
}
